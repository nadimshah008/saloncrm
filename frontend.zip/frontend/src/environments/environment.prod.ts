export const environment = {
  env: "prod",
  production: true,
  apiUrl: "https://bookapp.ch",
  baseUrl: "https://bookapp.ch",
  backendBaseUrl: "https://bookapp.ch"
};
