export const environment = {
  env: "staging",
  production: true,
  apiUrl: "https://meanstack.stagingsdei.com:5977",
  baseUrl: "https://meanstack.stagingsdei.com:5977",
  backendBaseUrl: "https://meanstack.stagingsdei.com:5977"
};
