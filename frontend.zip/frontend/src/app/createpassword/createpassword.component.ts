import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-createpassword",
  templateUrl: "./createpassword.component.html",
  styleUrls: ["./createpassword.component.css"]
})
export class CreatepasswordComponent implements OnInit {
  resetKey: any;
  constructor() {}

  ngOnInit() {}
}
