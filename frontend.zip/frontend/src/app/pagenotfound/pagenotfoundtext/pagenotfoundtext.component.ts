import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-pagenotfoundtext",
  templateUrl: "./pagenotfoundtext.component.html",
  styleUrls: ["./pagenotfoundtext.component.scss"]
})
export class PagenotfoundtextComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
